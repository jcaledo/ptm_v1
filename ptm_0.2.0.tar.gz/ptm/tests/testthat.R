library(testthat)
library(ptm)

test_check("ptm")
